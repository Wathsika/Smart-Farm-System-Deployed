// backend/events/orderEvent.js
import { EventEmitter } from "events";
const orderEvents = new EventEmitter();
export default orderEvents;
