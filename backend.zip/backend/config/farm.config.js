export default {
  name: process.env.FARM_NAME || 'Smart Farm',
  address: process.env.FARM_ADDRESS || 'Unknown Address',
  contact: process.env.FARM_CONTACT || 'N/A'
};