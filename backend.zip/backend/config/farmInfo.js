export const farmInfo = {
  name: "Smart Farm",
  address: "123 Country Lane, Colombo, Sri Lanka",
  phone: "+94 11 234 5678",
  email: "info@smartfarm.com"
};

export default farmInfo;